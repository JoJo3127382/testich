<?php
require ('db.php');
class families extends DB
{
    public function get(){
        return $this->DBAll('SELECT * from families');
    }
    public function getIn(){
        return $this->DBAll('SELECT * from families WHERE id_families');
    }
    
    public function getA(){
        return $this->DBAll('SELECT * from families WHERE status = "Сняты с учета"');
    }
    public function getR(){
        return $this->DBAll('SELECT * from families WHERE status = "На учете"');
    }
    public function deleteF($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from families where id_families='.$req->id_families,
            'Данные о семье удалены');
    }

    public function createF($request){
        $req = json_decode($request);
        $start = $req->start;
        $FIO_f = $req->FIO_f;
        $FIO_m = $req->FIO_m;
        $FIO_c = $req->FIO_c;
        $bdate_f = $req->bdate_f;
        $bdate_m = $req->bdate_m;
        $bdate_c = $req->bdate_c;
        $info = $req->info;
        $status = $req->status;
        $work_info = $req->work_info;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO families (start, FIO_f, FIO_m, FIO_c, bdate_f, bdate_m, bdate_c, info, status, work_info) values ('{$start}','{$FIO_f}','{$FIO_m}','{$FIO_c}','{$bdate_f}','{$bdate_m}','{$bdate_c}','{$info}','{$status}','{$work_info}')");
            $connect->commit();
            return json_encode([
                'message'=>'Данные о семье добавлены'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateF($request){
        $req = json_decode($request);
        $id_families = $req->id_families;
        $start = $req->start;
        $FIO_f = $req->FIO_f;
        $FIO_m = $req->FIO_m;
        $FIO_c = $req->FIO_c;
        $bdate_f = $req->bdate_f;
        $bdate_m = $req->bdate_m;
        $bdate_c = $req->bdate_c;
        $info = $req->info;
        $status = $req->status;
        $work_info = $req->work_info;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE families SET start='{$start}', FIO_f='{$FIO_f}', FIO_m='{$FIO_m}', FIO_c='{$FIO_c}', bdate_f='{$bdate_f}', bdate_m='{$bdate_m}', bdate_c='{$bdate_c}', info='{$info}', status='{$status}', work_info='{$work_info}' WHERE id_families={$id_families} ");
            $connect->commit();
            return json_encode([
                'message'=>'Данные о семье обновлены'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }

}