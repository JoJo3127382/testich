<?php

require ('db.php');

class users extends DB
{
        public function get(){
        return $this->DBAll('SELECT * from worker');
    }
    public function getU(){
        return $this->DBAll('SELECT * from users WHERE role>=3 ORDER BY role');
    }
    public function getLo(){
        return $this->DBAll('SELECT * from users');
    }

    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from worker where id_worker='.$req->id_worker,
            'Пользователь удален');
    }
    public function deleteUser($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from users where id_users='.$req->id_users,
            'Пользователь удален');
    }

    public function createUser($request){
        $req = json_decode($request);
        $last_name = $req->last_name;
        $name = $req->name;
        $father_name = $req->father_name;
        $password = $req->password;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO staff (last_name,name,father_name) values ('{$last_name}','{$name}','{$father_name}','{$password}')");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateU($request){
        $req = json_decode($request);
        $id_users = $req->id_users;
        $last_name = $req->last_name;
        $name = $req->name;
        $father_name = $req->father_name;
        $password = $req->password;
        $role = $req->role;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE users SET role='{$role}', SET last_name='{$last_name}', SET name='{$name}', SET father_name='{$father_name}', SET password='{$password}', WHERE id_users={$id_users} ");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function update($request){
        $req = json_decode($request);
        $id_staff = $req->id_staff;
        $last_name = $req->last_name;
        $name = $req->name;
        $father_name = $req->father_name;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE staff SET last_name='{$last_name}',name='{$name}',father_name='{$father_name}' WHERE id_staff={$id_staff}");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}