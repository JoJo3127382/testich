<!DOCTYPE html>
<html>
<head>
<h1>Акт первичного обследования
условий жизни семьи, предположительно находящейся в социально опасном положении</h1>

</head>
<style>
    body {
  font-family: Arial, sans-serif;
  background-color: #f9f9f9;
}

.h1 {
    margin-left: 5rem;
}

.column-cd {
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ddd;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.column-cd p {
  margin-bottom: 10px;
}

.column-cd input[type="text"] {
  width: 100%;
  height: 30px;
  margin-bottom: 20px;
  padding: 10px;
  border: 1px solid #ccc;
}

.column-cd button[type="submit"] {
  background-color: #4CAF50;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.column-cd button[type="submit"]:hover {
  background-color: #3e8e41;
}
</style>



<body>
<form method="POST" action="main.php">
<div class="column-cd" for="myInput" method="POST">
    <p>День обследования</p>
	<input type="text"  id="d_obs" name="d_obs" placeholder="День обследования">
    <p>Месяц обследования</p>
	<input type="text"  id="m_obs" name="m_obs" placeholder="Месяц обследования">
    <p>Год обследования</p>
	<input type="text"  id="g_obs" name="g_obs" placeholder="Год обследования">
    <p>Адрес по которому проводилось обследование</p>
	<input type="text"  id="ad_ob" name="ad_ob" placeholder="Адрес по которому проводилось обследование">
    <p>Наименование мун. образования</p>
	<input type="text"  id="naz_ob" name="naz_ob" placeholder="Наименование мун. образования">
    <p>Специалист</p>
	<input type="text"  id="spec_1" name="spec_1" placeholder="Специалист">
    <p>Специалист</p>
	<input type="text"  id="spec_2" name="spec_2" placeholder="Специалист">
    <p>Специалист</p>
	<input type="text"  id="spec_3" name="spec_3" placeholder="Специалист">
    <p>проводилось обследование у семьи</p>
	<input type="text"  id="semya" name="semya" placeholder="проводилось обследование у семьи">
    <p>ФИО Ребенок</p>
	<input type="text"  id="ijv" name="ijv" placeholder="ФИО Ребенок">
    <p>Серия паспорта</p>
	<input type="text"  id="ser_p" name="ser_p" placeholder="Серия паспорта">
    <p>Номер паспорта</p>
	<input type="text"  id="nom_p" name="nom_p" placeholder="Номер паспорта">
    <p>Кем и когда выдан</p>
	<input type="text"  id="vid_p" name="vid_p" placeholder="Кем и когда выдан">
    <p>Ребенок 1</p>
	<input type="text"  id="reb_1" name="reb_1" placeholder="Ребенок 1">
    <p>Ребенок 2</p>
	<input type="text"  id="reb_2" name="reb_2" placeholder="Ребенок 2">
    <p>Фио матери</p>
	<input type="text"  id="m_fio" name="m_fio" placeholder="Фио матери">
    <p>Дата и год рождения матери</p>
	<input type="text"  id="m_dg" name="m_dg" placeholder="Дата и год рождения матери">
    <p>Контактный телефон</p>
	<input type="text"  id="m_num" name="m_num" placeholder="Контактный телефон">
    <p>Паспорт матери</p>
	<input type="text"  id="m_pas" name="m_pas" placeholder="Паспорт матери">
    <p>Серия паспорта</p>
	<input type="text"  id="m_pas_s" name="m_pas_s" placeholder="Серия паспорта">
    <p>Номер паспорта</p>
	<input type="text"  id="m_pas_n" name="m_pas_n" placeholder="Номер паспорта">
    <p>Кем и когда выдан</p>
	<input type="text"  id="m_pas_v" name="m_pas_v" placeholder="Кем и когда выдан">
    <p>Адрес по регистрации</p>
	<input type="text"  id="m_adr_reg" name="m_adr_reg" placeholder="Адрес по регистрации">
    <p>Фактический адрес проживания</p>
	<input type="text"  id="m_adr_f" name="m_adr_f" placeholder="Фактический адрес проживания">
    <p>Сведения о трудовой деятельности</p>
	<input type="text"  id="m_rab" name="m_rab" placeholder="Сведения о трудовой деятельности">
    <p>Должность и место работы</p>
	<input type="text"  id="m_dolj" name="m_dolj" placeholder="Должность и место работы">
    <p>Месячный доход</p>
	<input type="text"  id="m_doh" name="m_doh" placeholder="Месячный доход">
    <p>Иные сведения</p>
	<input type="text"  id="m_in" name="m_in" placeholder="Иные сведения">
    <p>Проживание совместно</p>
	<input type="text"  id="m_proj" name="m_proj" placeholder="Проживание совместно">
    <p>Способ обеспечения основных потребностей детей</p>
	<input type="text"  id="m_obes" name="m_obes" placeholder="Способ обеспечения основных потребностей детей">
    <p>Иные сведения</p>
	<input type="text"  id="m_is" name="m_is" placeholder="Иные сведения">
    <p>ФИО отца</p>
	<input type="text"  id="f_fio" name="f_fio" placeholder="ФИО отца">
    <p>Дата и год рождения</p>
	<input type="text"  id="f_dg" name="f_dg" placeholder="Дата и год рождения">
    <p>Контактный телефон</p>
	<input type="text"  id="f_num" name="f_num" placeholder="Контактный телефон">
    <p>Документ удостоверяющий личность</p>
	<input type="text"  id="f_pas" name="f_pas"placeholder="Документ удостоверяющий личность">
    <p>Серия паспорта</p>
	<input type="text"  id="f_pas_s" name="f_pas_s"placeholder="Серия паспорта">
    <p>Номер паспорта</p>
	<input type="text"  id="f_pas_n" name="f_pas_n"placeholder="Номер паспорта">
    <p>Кем и когда выдан</p>
	<input type="text"  id="f_pas_v" name="f_pas_v"placeholder="Кем и когда выдан">
    <p>Адрес по регистрации</p>
	<input type="text"  id="f_reg" name="f_reg"placeholder="Адрес по регистрации">
    <p>Фактический адрес</p>
	<input type="text"  id="f_fj" name="f_fj"placeholder="Фактический адрес">
    <p>Работает/не работает</p>
	<input type="text"  id="f_rab" name="f_rab"placeholder="Работает/не работает">
    <p>Должность и место работы</p>
	<input type="text"  id="f_rab_d" name="f_rab_d"placeholder="Должность и место работы">
    <p>Месячный доход</p>
	<input type="text"  id="f_doh" name="f_doh"placeholder="Месячный доход">
    <p>Иные сведения</p>
	<input type="text"  id="f_is" name="f_is"placeholder="Иные сведения">
    <p>Проживает совместно или нет</p>
	<input type="text"  id="f_proj" name="f_proj"placeholder="Проживает совместно или нет">
    <p>Способность обеспечения основных потребностей</p>
	<input type="text"  id="f_obe" name="f_obe"placeholder="Способность обеспечения основных потребностей">
    <p>Иные сведения</p>
	<input type="text"  id="f_in_s" name="f_in_s"placeholder="Иные сведения">
    <p>Проживают совместно/раздельно</p>
	<input type="text"  id="r_proj" name="r_proj"placeholder="Проживают совместно/раздельно">
    <p>Общая оценка уровня физ развития и тд.</p>
	<input type="text"  id="d_fr" name="d_fr"placeholder="Общая оценка уровня физ развития и тд.">
    <p>иные сведения</p>
	<input type="text"  id="d_in" name="d_in"placeholder="иные сведения">
    <p>Внешний вид детей</p>
	<input type="text"  id="d_od" name="d_od"placeholder="Внешний вид детей">
    <p>Социальная адаптация детей</p>
	<input type="text"  id="d_adap" name="d_adap"placeholder="Социальная адаптация детей">
    <p>Образовательные организации</p>
	<input type="text"  id="d_ob_org" name="d_ob_org"placeholder="Образовательные организации">
    <p>Дополнительное образование</p>
	<input type="text"  id="d_dop_ob" name="d_dop_ob"placeholder="Дополнительное образование">
    <p>Иные сведения</p>
	<input type="text"  id="d_usp" name="d_usp"placeholder="Иные сведения">
    <p>Соблюдение режима дня</p>
	<input type="text"  id="d_rd" name="d_rd"placeholder="Соблюдение режима дня">
    <p>Иные сведения</p>
	<input type="text"  id="d_sv_v" name="d_sv_v"placeholder="Иные сведения">
    <p>Обеспечение безопасности детей</p>
	<input type="text"  id="d_bez" name="d_bez"placeholder="Обеспечение безопасности детей">
    <p>Отношения между членами семьи</p>
	<input type="text"  id="f_otn" name="f_otn"placeholder="Отношения между членами семьи">
    <p>Составляет кв.м</p>
	<input type="text"  id="k_p" name="k_p"placeholder="Составляет кв.м">
    <p>Комнат</p>
	<input type="text"  id="k_kom" name="k_kom"placeholder="Комнат">
    <p>1 комната</p>
	<input type="text"  id="k_r" name="k_r"placeholder="1 комната">
    <p>2 комната</p>
	<input type="text"  id="k_r1" name="k_r1"placeholder="2 комната">
    <p>Дом</p>
	<input type="text"  id="k_d" name="k_d"placeholder="Дом">
    <p>Состояние жилых комнат</p>
	<input type="text"  id="k_sj" name="k_sj"placeholder="Состояние жилых комнат">
    <p>Благоустройство дома</p>
	<input type="text"  id="k_b" name="k_b"placeholder="Благоустройство дома">
    <p>Собственник жилой площади</p>
	<input type="text"  id="k_sob" name="k_sob"placeholder="Собственник жилой площади">
    <p>Санитарно-гигиеническое состояние площади</p>
	<input type="text"  id="k_s" name="k_s"placeholder="Санитарно-гигиеническое состояние площади">
    <p>Жилищно-бытовые условия детей</p>
	<input type="text"  id="k_jb" name="k_jb"placeholder="Жилищно-бытовые условия детей">
    <p>Структура доходов семьи</p>
	<input type="text"  id="st_dh" name="st_dh"placeholder="Структура доходов семьи">
    <p>Сведения об имуществе</p>
	<input type="text"  id="imu" name="imu"placeholder="Сведения об имуществе">
    <p>Достаточность доходов</p>
	<input type="text"  id="dos_doh" name="dos_doh"placeholder="Достаточность доходов">
    <p>Сведения о результатах опроса лиц</p>
	<input type="text"  id="sved" name="sved"placeholder="Сведения о результатах опроса лиц">
    <p>Признаки нарушения прав</p>
	<input type="text"  id="f_nar" name="f_nar"placeholder="Признаки нарушения прав">
    <p>Указать в чем выражаются</p>
	<input type="text"  id="ukz" name="ukz"placeholder="Указать в чем выражаются">
    <p>Обстоятельства, свидетельствующие об уклонении от воспитания детей</p>
	<input type="text"  id="obst" name="obst"placeholder="Обстоятельства, свидетельствующие об уклонении от воспитания детей">
    <p>Сведения об иных родственниках</p>
	<input type="text"  id="rod" name="rod"placeholder="Сведения об иных родственниках">
    <p>Дополнительные данные обследования</p>
	<input type="text"  id="dop_inf" name="dop_inf"placeholder="Дополнительные данные обследования">
    <p>Нарушение прав и законных интересов</p>
	<input type="text"  id="viv" name="viv"placeholder="Нарушение прав и законных интересов">
    <p>Родительское попечение над детьми</p>
	<input type="text"  id="rod_pop" name="rod_pop"placeholder="Родительское попечение над детьми">
    <p>Помощь в которой нуждается семья</p>
	<input type="text"  id="pom" name="pom"placeholder="Помощь в которой нуждается семья">
    <button type="submit">Отправить</button>
</div>
</form> 
<?php


// $m_obs = $_POST ['m_obs']; 
// $d_obs = $_POST ['d_obs']; 
// $g_obs = $_POST ['g_obs']; 
// $ad_ob = $_POST ['ad_ob']; 
// $naz_ob = $_POST ['naz_ob']; 
// $spec_1 = $_POST ['spec_1']; 
// $spec_2 = $_POST ['spec_2']; 
// $spec_3 = $_POST ['spec_3']; 
// $semya = $_POST ['semya']; 
// $ijv = $_POST ['ijv'];  
// $ser_p = $_POST ['ser_p']; 
// $nom_p = $_POST ['nom_p']; 
// $vid_p = $_POST ['vid_p']; 
// $reb_1 = $_POST ['reb_1']; 
// $reb_2 = $_POST ['reb_2']; 
// $m_fio = $_POST ['m_fio']; 
// $m_dg = $_POST ['m_dg']; 
// $m_num = $_POST ['m_num']; 
// $m_pas = $_POST ['m_pas']; 
// $m_pas_s = $m_pas_s ['m_pas_s'];  
// $m_pas_n = $_POST ['m_pas_n']; 
// $m_pas_v = $_POST ['m_pas_v']; 
// $m_adr_reg = $_POST ['m_adr_reg']; 
// $m_adr_f = $_POST ['m_adr_f']; 
// $m_rab = $_POST ['m_rab']; 
// $m_dolj = $_POST ['m_dolj']; 
// $m_doh = $_POST ['m_doh']; 
// $m_in = $_POST ['m_in']; 
// $m_proj = $_POST ['m_proj']; 
// $m_obes = $_POST ['m_obes'];  
// $m_is = $_POST ['m_is']; 
// $f_fio = $_POST ['f_fio']; 
// $f_dg = $_POST ['f_dg']; 
// $f_num = $_POST ['f_num']; 
// $f_pas_s = $_POST ['f_pas_s']; 
// $f_pas_n = $_POST ['f_pas_n']; 
// $f_pas_v = $_POST ['f_pas_v']; 
// $f_reg = $_POST ['f_reg']; 
// $f_fj = $_POST ['f_fj']; 
// $f_rab = $_POST ['f_rab'];  
// $f_rab_d = $_POST ['f_rab_d']; 
// $f_doh = $_POST ['f_doh']; 
// $f_is = $_POST ['f_is']; 
// $f_obe = $_POST ['f_obe']; 
// $f_in_s = $_POST ['f_in_s']; 
// $r_proj = $_POST ['r_proj']; 
// $d_fr = $_POST ['d_fr']; 
// $d_in = $_POST ['d_in']; 
// $d_od = $_POST ['d_od']; 
// $d_adap = $_POST ['d_adap'];  
// $d_ob_org = $_POST ['d_ob_org'];  
// $d_dop_ob = $_POST ['d_dop_ob'];  
// $d_rd = $_POST ['d_rd'];  
// $d_sv_v = $_POST ['d_sv_v'];  
// $d_bez = $_POST ['d_bez'];  
// $f_otn = $_POST ['f_otn'];  
// $k_p = $_POST ['k_p'];  
// $k_kom = $_POST ['k_kom'];  
// $k_r = $_POST ['k_r'];  
// $k_r1 = $_POST ['k_r1'];  
// $k_d = $_POST ['k_d']; 
// $k_sj = $_POST ['k_sj'];  
// $k_b = $_POST ['k_b'];  
// $k_sob = $_POST ['k_sob'];  
// $k_s = $_POST ['k_s'];  
// $k_jb = $_POST ['k_jb'];  
// $st_dh = $_POST ['st_dh']; 
// $imu = $_POST ['imu'];  
// $dos_doh = $_POST ['dos_doh'];  
// $sved = $_POST ['sved'];  
// $f_nar = $_POST ['f_nar'];  
// $ukz = $_POST ['ukz'];  
// $obst = $_POST ['obst']; 
// $rod = $_POST ['rod']; 
// $dop_inf = $_POST ['dop_inf']; 
// $viv = $_POST ['viv']; 
// $rod_pop = $_POST ['rod_pop']; 
// $pom = $_POST ['pom']; 

require 'vendor/autoload.php';
$phpWord = new \PhpOffice\PhpWord\PhpWord();
$document = new \PhpOffice\PhpWord\TemplateProcessor('Template.docx');
$uploadDIR = __DIR__;
$outputFile = 'Акт.docx';

$m_obs = $_POST ['m_obs']; 
$d_obs = $_POST ['d_obs']; 
$g_obs = $_POST ['g_obs']; 
$ad_ob = $_POST ['ad_ob']; 
$naz_ob = $_POST ['naz_ob']; 
$spec_1 = $_POST ['spec_1']; 
$spec_2 = $_POST ['spec_2']; 
$spec_3 = $_POST ['spec_3']; 
$semya = $_POST ['semya']; 
$ijv = $_POST ['ijv'];  
$ser_p = $_POST ['ser_p']; 
$nom_p = $_POST ['nom_p']; 
$vid_p = $_POST ['vid_p']; 
$reb_1 = $_POST ['reb_1']; 
$reb_2 = $_POST ['reb_2']; 
$m_fio = $_POST ['m_fio']; 
$m_dg = $_POST ['m_dg']; 
$m_num = $_POST ['m_num']; 
$m_pas = $_POST ['m_pas']; 
$m_pas_s = $m_pas_s ['m_pas_s'];  
$m_pas_n = $_POST ['m_pas_n']; 
$m_pas_v = $_POST ['m_pas_v']; 
$m_adr_reg = $_POST ['m_adr_reg']; 
$m_adr_f = $_POST ['m_adr_f']; 
$m_rab = $_POST ['m_rab']; 
$m_dolj = $_POST ['m_dolj']; 
$m_doh = $_POST ['m_doh']; 
$m_in = $_POST ['m_in']; 
$m_proj = $_POST ['m_proj']; 
$m_obes = $_POST ['m_obes'];  
$m_is = $_POST ['m_is']; 
$f_fio = $_POST ['f_fio']; 
$f_dg = $_POST ['f_dg']; 
$f_num = $_POST ['f_num']; 
$f_pas_s = $_POST ['f_pas_s']; 
$f_pas_n = $_POST ['f_pas_n']; 
$f_pas_v = $_POST ['f_pas_v']; 
$f_reg = $_POST ['f_reg']; 
$f_fj = $_POST ['f_fj']; 
$f_rab = $_POST ['f_rab'];  
$f_rab_d = $_POST ['f_rab_d']; 
$f_doh = $_POST ['f_doh']; 
$f_is = $_POST ['f_is']; 
$f_obe = $_POST ['f_obe']; 
$f_in_s = $_POST ['f_in_s']; 
$r_proj = $_POST ['r_proj']; 
$d_fr = $_POST ['d_fr']; 
$d_in = $_POST ['d_in']; 
$d_od = $_POST ['d_od']; 
$d_adap = $_POST ['d_adap'];  
$d_ob_org = $_POST ['d_ob_org'];  
$d_dop_ob = $_POST ['d_dop_ob'];  
$d_rd = $_POST ['d_rd'];  
$d_sv_v = $_POST ['d_sv_v'];  
$d_bez = $_POST ['d_bez'];  
$f_otn = $_POST ['f_otn'];  
$k_p = $_POST ['k_p'];  
$k_kom = $_POST ['k_kom'];  
$k_r = $_POST ['k_r'];  
$k_r1 = $_POST ['k_r1'];  
$k_d = $_POST ['k_d']; 
$k_sj = $_POST ['k_sj'];  
$k_b = $_POST ['k_b'];  
$k_sob = $_POST ['k_sob'];  
$k_s = $_POST ['k_s'];  
$k_jb = $_POST ['k_jb'];  
$st_dh = $_POST ['st_dh']; 
$imu = $_POST ['imu'];  
$dos_doh = $_POST ['dos_doh'];  
$sved = $_POST ['sved'];  
$f_nar = $_POST ['f_nar'];  
$ukz = $_POST ['ukz'];  
$obst = $_POST ['obst']; 
$rod = $_POST ['rod']; 
$dop_inf = $_POST ['dop_inf']; 
$viv = $_POST ['viv']; 
$rod_pop = $_POST ['rod_pop']; 
$pom = $_POST ['pom']; 

$document->setValues(
    [
        $document->setValue('d_obs', $d_obs),
        $document->setValue('m_obs', $m_obs),
        $document->setValue('g_obs', $g_obs),
        $document->setValue('ad_ob', $ad_ob),
        $document->setValue('naz_ob', $naz_ob),
        $document->setValue('spec_1', $spec_1),
        $document->setValue('spec_2', $spec_2),
        $document->setValue('spec_3', $spec_3),
        $document->setValue('semya', $semya),
        $document->setValue('ijv', $ijv),
        $document->setValue('ser_p', $ser_p),
        $document->setValue('nom_p', $nom_p),
        $document->setValue('vid_p', $vid_p),
        $document->setValue('reb_1', $reb_1),
        $document->setValue('reb_2', $reb_2),
        $document->setValue('m_fio', $m_fio),
        $document->setValue('m_dg', $m_dg),
        $document->setValue('m_num', $m_num),
        $document->setValue('m_pas', $m_pas),
        $document->setValue('m_pas_s', $m_pas_s),
        $document->setValue('m_adr_reg', $m_adr_reg),
        $document->setValue('m_adr_f', $m_adr_f),
        $document->setValue('m_rab', $m_rab),
        $document->setValue('m_dolj', $m_dolj),
        $document->setValue('m_doh', $m_doh),
        $document->setValue('m_in', $m_in),
        $document->setValue('m_proj', $m_proj),
        $document->setValue('m_obes', $m_obes),
        $document->setValue('m_is', $m_is),
        $document->setValue('f_fio', $f_fio),
        $document->setValue('f_dg', $f_dg),
        $document->setValue('f_num', $f_num),
        $document->setValue('f_pas', $f_pas),
        $document->setValue('f_pas_s', $f_pas_s),
        $document->setValue('f_pas_n', $f_pas_n),
        $document->setValue('f_pas_v', $f_pas_v),
        $document->setValue('f_reg', $f_reg),
        $document->setValue('f_fj', $f_fj),
        $document->setValue('f_rab', $f_rab),
        $document->setValue('f_rab_d', $f_rab_d),
        $document->setValue('f_is', $f_is),
        $document->setValue('f_proj', $f_proj),
        $document->setValue('f_obe', $f_obe),
        $document->setValue('f_in_s', $f_in_s),
        $document->setValue('r_proj', $r_proj),
        $document->setValue('d_fr', $d_fr),
        $document->setValue('d_in', $d_in),
        $document->setValue('d_od', $d_od),
        $document->setValue('d_adap', $d_adap),
        $document->setValue('d_ob_org', $d_ob_org),
        $document->setValue('d_dop_ob', $d_dop_ob),
        $document->setValue('d_usp', $d_usp),
        $document->setValue('d_rd', $d_rd),
        $document->setValue('d_sv_v', $d_sv_v),
        $document->setValue('d_bez', $d_bez),
        $document->setValue('f_otn', $f_otn),
        $document->setValue('k_p', $k_p),
        $document->setValue('k_kom', $k_kom),
        $document->setValue('k_r', $k_r),
        $document->setValue('k_r1', $k_r1),
        $document->setValue('k_d', $k_d),
        $document->setValue('k_sj', $k_sj),
        $document->setValue('k_b', $k_b),
        $document->setValue('k_sob', $k_sob),
        $document->setValue('k_s', $k_s),
        $document->setValue('k_jb', $k_jb),
        $document->setValue('st_dh', $st_dh),
        $document->setValue('imu', $imu),
        $document->setValue('dos_doh', $dos_doh),
        $document->setValue('sved', $sved),
        $document->setValue('f_nar', $f_nar),
        $document->setValue('ukz', $ukz),
        $document->setValue('obst', $obst),
        $document->setValue('rod', $rod),
        $document->setValue('dop_inf', $dop_inf),
        $document->setValue('viv', $viv),
        $document->setValue('rod_pop', $rod_pop),
        $document->setValue('pom', $pom),
    ]
    );

$document->saveAs($outputFile);


?>
</body>
</html>