<?php
require_once('../controllers/User.php');
$db = new users();
$id_worker = $_POST['id_worker'];
$last_name = $_POST['last_name'];
$name = $_POST['name'];
$father_name = $_POST['father_name'];
$password = md5($_POST['password']);
$res = $db->update(json_encode([
    'id_worker'=>$id_worker,
    'last_name'=>$last_name,
    'name'=>$name,
    'father_name'=>$father_name,
    'password'=>$password
]));

header('Location: ../../views/users/index.php?message='.json_decode($res)->message);
