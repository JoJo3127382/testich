<div class="d-flex">
    <a class="knopka" href="../auth/index.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require ('../../controllers/families.php');
?>

<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">

    <div>
        <a class="knopka" href="../families/create.php">Добавить данные о новой семье</a>
        <a class="knopka" href="../families/update.php">Редактировать данные о семье</a>
        <a class="knopka" href="../families/delete.php">Удалить данные о семье</a>
        <a class="knopka" href="../families/archive.php">Архив</a>
    </div>
</div>
<div class="container">
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>ФИО матери</th>
        <th>Информация о семье</th>
        <th>Статус</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $db= new families();
    $data = $db->getA();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['FIO_m'];?></td>
            <td><?php echo $row['info'];?></td>
            <td><?php echo $row['status'];?></td>
            <td><?php echo $row['work_info'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>
</div>
<?php
require ('../layout/footer.php');
?>