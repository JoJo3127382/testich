<?php
require_once('../../controllers/families.php');
$db = new families();
$start = $_POST['start'];
$FIO_f = $_POST['FIO_f'];
$FIO_m = $_POST['FIO_m'];
$FIO_c = $_POST['FIO_c'];
$bdate_f = $_POST['bdate_f'];
$bdate_m = $_POST['bdate_m'];
$bdate_c = $_POST['bdate_c'];
$info = $_POST['info'];
$status= $_POST['status'];
$response = $db->updateF(json_encode([
    'start'=>$start,
    'FIO_f'=>$FIO_f,
    'FIO_m'=>$FIO_m,
    'FIO_c'=>$FIO_c,
    'bdate_f'=>$bdate_f,
    'bdate_m'=>$bdate_m,
    'bdate_c'=>$bdate_c,
    'info'=>$info,
    'status'=>$status,
]));

header('Location: ../../views/auth/index.php?message='.json_decode($response)->message);
