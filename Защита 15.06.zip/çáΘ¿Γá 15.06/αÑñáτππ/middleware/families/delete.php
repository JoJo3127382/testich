<?php
require_once ('../../controllers/families.php');
$db = new families();
$id_families = $_POST['id_families'];

$res = $db->deleteF(json_encode([
    'id_families'=>$id_families
]));

header('Location: ../../views/auth/index.php?message='. json_decode($res)->message);