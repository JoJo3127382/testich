<?php
require('../controllers/services.php');
$db = new services();
$id_services = $_POST['id_services'];
$service = $_POST['service'];
$date = $_POST['date'];
$info = $_POST['info'];


$response = $db->createServices(json_encode([
    'id_services'=>$id_services,
    'service'=>$service,
    'date'=>$date,
    'info'=>$info

]));

header('Location: ../index2.php?message='.json_decode($response)->message);