<?php
require('../layout/header.php');
require_once('menu3.php');
require('../../controllers/services.php');
$db = new services();
?>
<div class="container mt-5">
    <form action="../../middleware/createServices.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-5">
            <label for="service">Проведенная работа</label>
            <input id="service" name="service" type="text" class="form-control" placeholder="Проведенная работа и семья" required>
        </div>
        <div class="col-5">
            <label for="date">Дата</label>
            <input id="date" name="date" type="date" class="form-control" placeholder="Дата проведенной работы" required>
        </div>
        <div class="col-5">
            <label for="info">Информация</label>
            <input id="info" name="info" type="text" class="form-control" placeholder="Информация" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Добавить</button>
        </div>
    </form>
</div>
