<?php
// Подключение к базе данных
$servername = "localhost";
$username = "20087";
$password = "ceyeov";
$dbname = "20087_families";

$conn = new PDO('mysql:host=localhost;dbname=20087_families;charset=utf8','root','');

// Запрос к базе данных
$sql = "SELECT * FROM services";
$result = $conn->query($sql);

// Создание файла CSV
// Создание файла CSV
$fp = fopen('output.csv', 'w');

// Specify UTF-8 encoding
fprintf($fp, chr(0xEF). chr(0xBB). chr(0xBF));

// Запись заголовков в файл CSV
$headers = array();
for ($i = 0; $i < $result->columnCount(); $i++) {
    $meta = $result->getColumnMeta($i);
    $headers[] = $meta['name'];
}
fputcsv($fp, $headers, ';', '"'); // Use semicolon as delimiter and double quote as enclosure


// Запись данных в файл CSV
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $formattedRow = array();
    foreach ($row as $key => $value) {
        if (strpos($key, 'date')!== false || strpos($key, 'datetime')!== false) {
            $dt = new DateTime($value);
            $formattedRow[$key] = $dt->format('Y-m-d H:i:s');
        } else {
            $formattedRow[$key] = $value;
        }
    }
    fputcsv($fp, $formattedRow, ';', '"');
}

// Закрытие файла CSV
fclose($fp);

// Закрытие подключения к базе данных
$conn = null;
?>