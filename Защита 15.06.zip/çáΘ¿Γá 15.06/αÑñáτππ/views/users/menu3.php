
<div>
    <a class="knopka" href="../../index2.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>Проделанная работа</div>
    <div>
        <a class="knopka" href="update_service.php">Изменить данные о проделанной работе</a>
        <a class="knopka" href="delete_service.php">Удалить данные о проделанной работе</a>
        <a class="knopka" href="services_ot.php">Формирование отчета</a>
    </div>
</div>