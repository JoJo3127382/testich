<div class="d-flex">
    <a class="knopka" href="../auth/index.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require ('../../controllers/families.php');
?>
<style>
    .square-i {
  width: 800px;
  height: 800px;
  background-color: white;
  border-radius: 10px; /* rounded corners */
  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.6); /* box shadow */
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  justify-content: center; 
  align-items: top;
  display: flex;
  color: black;
  font-size: 52px;
  font-weight: bold;
}

</style>

<div class="container">
<table class="table table-hover table-dark">

<thead>
    <tr>
        <th> </th>
        <th>ID</th>
        <th>Дата постановки на учёт</th>
        <th>ФИО отца</th>
        <th>ФИО матери</th>
        <th>ФИО ребенка</th>
        <th>Дата рождения отца</th>
        <th>Дата рождения матери</th>
        <th>Дата рождения ребенка</th>
        <th>Информация о семье</th>
        <th>Статус</th>
    </tr>
    </thead>
<tbody>
<?php
$db= new families();
$data = $db->get();
foreach ($data as $key=>$row){
    ?>
    <tr>
        <td><?php echo ++$key;?></td>
        <td><?php echo $row['id_families'];?></td>
        <td><?php echo $row['start'];?></td>
        <td><?php echo $row['FIO_f'];?></td>
        <td><?php echo $row['FIO_m'];?></td>
        <td><?php echo $row['FIO_c'];?></td>
        <td><?php echo $row['bdate_f'];?></td>
        <td><?php echo $row['bdate_m'];?></td>
        <td><?php echo $row['bdate_c'];?></td>
        <td><?php echo $row['info'];?></td>
        <td><?php echo $row['status'];?></td>
    </tr>
<?php }?>
</tbody>
</div>
