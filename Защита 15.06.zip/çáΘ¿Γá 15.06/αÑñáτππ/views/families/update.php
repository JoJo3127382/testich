<?php
require ('../layout/header.php');
require_once('../../controllers/families.php');
$db = new families();
?>
    <table class="table table-hover table-info">
        <thead>
        <tr>
            <th>id</th>
            <th>ФИО отца</th>
            <th>ФИО матери</th>
            <th>ФИО ребенка</th>
            <th>Дата рождения отца</th>
            <th>Дата рождения матери</th>
            <th>Дата рождения ребенка</th>
            <th>Дата постановки на учет</th>
            <th>Информация о семье</th>
            <th>Статус</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $data = $db->get();
        foreach ($data as $key => $row) {
            ?>
            <tr>
                <form class="mx-2" action="../../middleware/families/update.php" method="post">
                    <td>
                        <?php echo ++$key; ?>
                        <input id="id_families" name="id_families" type="text" value="<?php echo $row["id_families"]; ?>" class="form-control" hidden
                               required>
                    </td>
                    <td>
                        <input id="FIO_f" name="FIO_f" type="text" value="<?php echo $row["FIO_f"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="FIO_m" name="FIO_m" type="text" value="<?php echo $row["FIO_m"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="FIO_c" name="FIO_c" type="text" value="<?php echo $row["FIO_c"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="bdate_f" name="bdate_f" type="date" value="<?php echo $row["bdate_f"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="bdate_m" name="bdate_m" type="date" value="<?php echo $row["bdate_m"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="bdate_c" name="bdate_c" type="date" value="<?php echo $row["bdate_c"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="start" name="start" type="date" value="<?php echo $row["start"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="info" name="info" type="text" value="<?php echo $row["info"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="status" name="status" type="text" value="<?php echo $row["status"]; ?>" class="form-control"
                               required>
                               
                    </td>
                    <td>
                        <button type="submit" class="btn btn-primary">Изменить</button>
                    </td>
                </form>
            </tr>
        <?php } ?>
        </tbody>
    </table>
