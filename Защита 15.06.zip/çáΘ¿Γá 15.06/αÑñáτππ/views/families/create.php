<div>
    <a class="knopka" href="../auth/menu2.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/families.php');
?>
    <div class="container mt-5">
        <form action="../../middleware/families/createF.php"
              method="post"
              class="d-flex flex-column justify-content-center align-items-center">
            <h3>Создание</h3>
                <div class="col-3">
                  <label for="FIO_f">ФИО отца</label>
                  <input id="FIO_f" name="FIO_f" type="text" class="form-control" placeholder="ФИО отца" required>
                 </div>
                 <div class="col-3">
                  <label for="FIO_m">ФИО матери</label>
                  <input id="FIO_m" name="FIO_m" type="text" class="form-control" placeholder="ФИО матери" required>
                 </div>
                 <div class="col-3">
                  <label for="FIO_c">ФИО ребенка</label>
                  <input id="FIO_c" name="FIO_c" type="text" class="form-control" placeholder="ФИО ребенка" required>
                 </div>
                 <div class="col-3">
                  <label for="bdate_f">Дата рождения отца</label>
                  <input id="bdate_f" name="bdate_f" type="date" class="form-control" placeholder="Дата рождения отца" required>
                 </div>
                 <div class="col-3">
                  <label for="bdate_m">Дата рождения матери</label>
                  <input id="bdate_m" name="bdate_m" type="date" class="form-control" placeholder="Дата рождения матери" required>
                 </div>
                 <div class="col-3">
                  <label for="bdate_c">Дата рождения ребенка</label>
                  <input id="bdate_c" name="bdate_c" type="date" class="form-control" placeholder="Дата рождения ребенка" required>
                 </div>
                 <div class="col-3">
                  <label for="info">Информация о семье</label>
                  <input id="info" name="info" type="text" class="form-control" placeholder="Информация о семье" required>
                 </div>
                 <div class="col-3">
                  <label for="start">Дата постановки на учет</label>
                  <input id="start" name="start" type="date" class="form-control" placeholder="Дата постановки на учет" required>
                 </div>
                 <div class="col-3">
                  <label for="work_info">Проделанная работа с семьей</label>
                  <input id="work_info" name="work_info" type="text" class="form-control" placeholder="Проделанная работа" required>
                 </div>
                <div class="col-3">
                <label for="status">Статус</label>
                <select name="status" id="status"  class="form-control" required>
                    <option value="На учете">На учете</option>
                    <option value="Сняты с учета">Сняты с учета</option>
                </select>
                </div>
            </div>
            <div class="mt-3-1">
                <button class="btn btn-primary" type="submit">Отправить</button>
            </div>
        </form>
    </div>