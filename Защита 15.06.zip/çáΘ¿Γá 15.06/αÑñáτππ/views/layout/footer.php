<!doctype html>
<html lang="ru">
<body>
<div class="container d-flex" style="background-color: #E9ECE9">
<script defer src="js/jquery-3.6.3.js"></script>
<form id="search-highlight" method="post" action="#">
  <!-- добавляем текстовое поле ввода, где будем писать наш поисковый запрос -->
  <input type="text" name="term" id="term" />
  <!-- добавляем кнопку, которая запускает поиск -->
  <input type="submit" name="submit" id="submit" value="Найти" />
  <!-- конец формы -->
</form>
<!-- сразу после формы будем писать, сколько совпадений мы нашли -->
<p class="results"></p>
<!-- а в этом блоке разместим наш основной текст -->
<div class="content">
  Поиск по сайту
</div>

</div>
</body>
</html>