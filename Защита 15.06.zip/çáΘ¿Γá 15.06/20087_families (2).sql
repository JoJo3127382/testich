-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 14 2024 г., 17:04
-- Версия сервера: 10.4.27-MariaDB
-- Версия PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `20087_families`
--

-- --------------------------------------------------------

--
-- Структура таблицы `families`
--

CREATE TABLE `families` (
  `id_families` int(11) NOT NULL,
  `start` date NOT NULL,
  `FIO_f` varchar(80) NOT NULL,
  `FIO_m` varchar(80) NOT NULL,
  `FIO_c` varchar(80) NOT NULL,
  `bdate_f` varchar(20) NOT NULL,
  `bdate_m` varchar(25) NOT NULL,
  `bdate_c` varchar(25) NOT NULL,
  `info` varchar(999) NOT NULL,
  `status` varchar(15) NOT NULL,
  `work_info` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `families`
--

INSERT INTO `families` (`id_families`, `start`, `FIO_f`, `FIO_m`, `FIO_c`, `bdate_f`, `bdate_m`, `bdate_c`, `info`, `status`, `work_info`) VALUES
(18, '2024-05-31', 'Петров Петр Петрович', 'Петрова Анастасия Петровна', 'Петров Петр Петрович', '2024-05-11', '2024-05-12', '', 'l,gkfmundybtrvrccrvtbyuio,muyntbrvecevtbynumyntbrvecetvbynumimuyntbrvfc', 'Сняты с учета', ''),
(19, '2024-05-08', 'bttntyn', 'yntynty', 'ntyntyn', '2024-05-09', '2024-05-18', '', 'ntyntntynntyntyntyntyntyntyntyntyntyntyntynt', 'На учете', ''),
(20, '2024-12-02', 'Капронов Иван Игоревич', 'Капронова Мария Юрьевна', 'Капронов Егор Иванович', '1985-12-10', '1988-11-05', '', 'Адрес: г. Иркутск, ул. Пустынная, д.11 Неблагополучная семья,, несовершеннолетний не приступил к обучению в общеобразовательном учреждении ', 'На учете', ''),
(21, '2024-06-10', 'trt', 'rtb', 'rtb', '2024-06-08', '2024-06-16', '2024-06-28', 'btr', 'На учете', '');

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `id_services` int(11) NOT NULL,
  `date` varchar(25) NOT NULL,
  `service` varchar(450) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `info` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`id_services`, `date`, `service`, `worker_id`, `info`) VALUES
(16, '2024-06-29', 'dbdbdr', 0, 'brrbrb'),
(17, '2024-06-26', 'rbrtbrbt', 0, 'rbtttttttttttttttttttttt'),
(18, '2024-06-14', 'иееркеркр', 0, 'еркекеееккр'),
(19, '2024-06-16', 'Социальный патронаж (Ивановы)', 0, 'На момент посещения дома находились все члены семьи, в квартире чисто');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `father_name` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_users`, `last_name`, `name`, `father_name`, `password`, `role`) VALUES
(1, '1', '1', '1', 'c4ca4238a0b923820dcc509a6f75849b', 3),
(2, 'admin', 'admin', 'admin', '202cb962ac59075b964b07152d234b70', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `worker`
--

CREATE TABLE `worker` (
  `id_worker` int(11) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `father_name` varchar(45) NOT NULL,
  `id_family` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `worker`
--

INSERT INTO `worker` (`id_worker`, `last_name`, `name`, `father_name`, `id_family`) VALUES
(8, 'Макрицкий', 'Андрей', 'Владимирович', 0),
(9, 'Иванов', 'Иван', 'Иванович', 0),
(10, '2', '2', '2', 0),
(11, '3', '3', '3', 0),
(12, '5', '5', '5', 0),
(13, '4', '4', '4', 0),
(14, '9', '9', '9', 0),
(15, '8', '8', '8', 0),
(16, '1', '1', '1', 0),
(17, 'admin', 'admin', 'admin', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id_families`);

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id_services`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- Индексы таблицы `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`id_worker`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `families`
--
ALTER TABLE `families`
  MODIFY `id_families` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `id_services` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `worker`
--
ALTER TABLE `worker`
  MODIFY `id_worker` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
